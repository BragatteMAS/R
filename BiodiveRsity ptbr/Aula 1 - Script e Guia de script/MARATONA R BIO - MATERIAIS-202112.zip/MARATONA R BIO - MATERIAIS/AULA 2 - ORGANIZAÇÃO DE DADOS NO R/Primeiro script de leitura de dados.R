# Nosso primeiro script de leitura de dados
# Prof Marcos Vital, para Maratona de análise de Biodiversidade da Academia do R
# Script criado em 14-12-2021

#Vamos ler os dados do arquivo exemplo.csv:
dados.exemplo <- read.csv ("exemplo.csv")

dados.exemplo